var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c252de44-de7f-4b1c-84a0-0c94ae31378c"],"propsByKey":{"c252de44-de7f-4b1c-84a0-0c94ae31378c":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":".pj_R2mFdHM8Likjcd8XD9o2rSkanUX2","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/c252de44-de7f-4b1c-84a0-0c94ae31378c.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var pedrinho = createSprite(22,20,15,15);
     pedrinho.shapeColor = "blue";
 
 var parede1 = createSprite(70,15,20,70);            
     parede1.shapeColor = "red";

 var parede2 = createSprite(25,112,70,20);
     parede2.shapeColor = "red";

 var parede3 = createSprite(95,50,70,20);
     parede3.shapeColor = "red";

 var parede4 = createSprite(65,137,20,70);
     parede4.shapeColor = "red";

 var parede5 = createSprite(160,112,70,20);
     parede5.shapeColor = "red";

 var parede6 = createSprite(165,50,70,20);
     parede6.shapeColor = "red";
   
 var parede7 = createSprite(230,50,70,20);
     parede7.shapeColor = "red";
   
 var parede8 = createSprite(130,137,20,70);
     parede8.shapeColor = "red";
   
 var parede9 = createSprite(195,137,20,70);
     parede9.shapeColor = "red";
   
 var parede10 = createSprite(260,137,20,70);
     parede10.shapeColor = "red";
   
 var parede11 = createSprite(65,202,20,70);
     parede11.shapeColor = "red"; 
   
 var parede12 = createSprite(40,247,70,20);
     parede12.shapeColor = "red";
   
 var parede13 = createSprite(10,272,20,70);
     parede13.shapeColor = "red";
   
 var parede14 = createSprite(35,306,70,20);
     parede14.shapeColor = "red";
  
 var parede15 = createSprite(65,331,20,70);
     parede15.shapeColor = "red"; 
 
 var parede16 = createSprite(90,368,70,20);
     parede16.shapeColor = "red"; 
   
 var parede17 = createSprite(130,270,20,70);
     parede17.shapeColor = "red"; 
   
 var parede18 = createSprite(130,200,20,70);
     parede18.shapeColor = "red";  
   
 var parede19 = createSprite(195,201,20,70);
     parede19.shapeColor = "red";  
   
 var parede20 = createSprite(195,270,20,70);
     parede20.shapeColor = "red";
  
 var parede21 = createSprite(165,295,70,20);
     parede21.shapeColor = "red";
   
 var parede22 = createSprite(165,368,80,20);
     parede22.shapeColor = "red";
   
 var parede23 = createSprite(225,368,70,20);
     parede23.shapeColor = "red";  
   
 var parede24 = createSprite(260,343,20,70);
     parede24.shapeColor = "red"; 
   
 var parede25 = createSprite(260,295,20,70);
     parede25.shapeColor = "red";  
   
 var parede26 = createSprite(260,265,20,70);
     parede26.shapeColor = "red"; 
   
 var parede27 = createSprite(260,205,20,70);
     parede27.shapeColor = "red";  
   
 var parede28 = createSprite(294,195,70,20);
     parede28.shapeColor = "red";  
   
 var parede29 = createSprite(334,125,20,160);
     parede29.shapeColor = "red";   
   
 var parede30 = createSprite(300,50,85,20);
     parede30.shapeColor = "red";  
   
 var moeda1 = createSprite(297,164,15,15);
     moeda1.shapeColor = "YELLOW"; 
 
 var moeda2 = createSprite(160,329,15,15);
     moeda2.shapeColor = "YELLOW";
 
 var moeda3 = createSprite(38,276,15,15);
     moeda3.shapeColor = "YELLOW"; 
 
 var jorge = createSprite(225,80,15,15);
     jorge.shapeColor = "GREEN";
 
 jorge.velocityY = 8;
 
 var pontos = 0;

function draw() {
  background("white");
   drawSprites();

  fill("black");
  textSize(20);
  text("pontuação: " + pontos,102,20);
 
  if (keyDown(RIGHT_ARROW)){
    pedrinho.velocityX = 2;
    pedrinho.velocityY = 0;
  }
  if (keyDown(LEFT_ARROW)){
    pedrinho.velocityX = -2;
    pedrinho.velocityY = 0;
  }
  if (keyDown(UP_ARROW)){
    pedrinho.velocityX = 0;
    pedrinho.velocityY = -2;
  }
  if (keyDown(DOWN_ARROW)){
    pedrinho.velocityX = 0;
    pedrinho.velocityY = 2;
  }

   createEdgeSprites();
   pedrinho.bounceOff(rightEdge);
   pedrinho.bounceOff(leftEdge);
   pedrinho.bounceOff(topEdge);
   pedrinho.bounceOff(parede1);
   pedrinho.bounceOff(parede2);
   pedrinho.bounceOff(parede3);
   pedrinho.bounceOff(parede4);
   pedrinho.bounceOff(parede5);
   pedrinho.bounceOff(parede6);
   pedrinho.bounceOff(parede7);
   pedrinho.bounceOff(parede8);
   pedrinho.bounceOff(parede10);
   pedrinho.bounceOff(parede11);
   pedrinho.bounceOff(parede12);
   pedrinho.bounceOff(parede13);
   pedrinho.bounceOff(parede14);
   pedrinho.bounceOff(parede15);
   pedrinho.bounceOff(parede16);
   pedrinho.bounceOff(parede17);
   pedrinho.bounceOff(parede18);
   pedrinho.bounceOff(parede19);
   pedrinho.bounceOff(parede20);
   pedrinho.bounceOff(parede21);
   pedrinho.bounceOff(parede22);
   pedrinho.bounceOff(parede23);
   pedrinho.bounceOff(parede24);
   pedrinho.bounceOff(parede25);
   pedrinho.bounceOff(parede26);
   pedrinho.bounceOff(parede27);
   pedrinho.bounceOff(parede28);
   pedrinho.bounceOff(parede29);
   pedrinho.bounceOff(parede30);

   
   jorge.bounceOff(rightEdge);
   jorge.bounceOff(leftEdge);
   jorge.bounceOff(topEdge);
   jorge.bounceOff(parede1);
   jorge.bounceOff(parede2);
   jorge.bounceOff(parede3);
   jorge.bounceOff(parede4);
   jorge.bounceOff(parede5);
   jorge.bounceOff(parede6);
   jorge.bounceOff(parede7);
   jorge.bounceOff(parede8);
   jorge.bounceOff(parede10);
   jorge.bounceOff(parede11);
   jorge.bounceOff(parede12);
   jorge.bounceOff(parede13);
   jorge.bounceOff(parede14);
   jorge.bounceOff(parede15);
   jorge.bounceOff(parede16);
   jorge.bounceOff(parede17);
   jorge.bounceOff(parede18);
   jorge.bounceOff(parede19);
   jorge.bounceOff(parede20);
   jorge.bounceOff(parede21);
   jorge.bounceOff(parede22);
   jorge.bounceOff(parede23);
   jorge.bounceOff(parede24);
   jorge.bounceOff(parede25);
   jorge.bounceOff(parede26);
   jorge.bounceOff(parede27);
   jorge.bounceOff(parede28);
   jorge.bounceOff(parede29);
   jorge.bounceOff(parede30);

  
  
  
  
  
  if (pedrinho.isTouching(moeda1))
  {
    moeda1.destroy();
    pontos = pontos +1;
  }
  
  if (pedrinho.isTouching(moeda2))
  {
    moeda2.destroy();
    pontos = pontos +1;
  }
  
  if (pedrinho.isTouching(moeda3))
  {
    moeda3.destroy();
    pontos = pontos +1;
  }

  if (pedrinho.isTouching(jorge))
  {
    pedrinho.setVelocity(0,0);
    textSize(24);
    text("você perdeu",200,200);
    parede1.destroy();
    parede2.destroy();
    parede3.destroy();
    parede4.destroy();
    parede5.destroy();
    parede6.destroy();
    parede7.destroy();
    parede8.destroy();
    parede9.destroy();
    parede10.destroy();
    parede11.destroy();
    parede12.destroy();
    parede13.destroy();
    parede14.destroy();
    parede15.destroy();
    parede16.destroy();  
    parede17.destroy();
    parede18.destroy();
    parede19.destroy();
    parede20.destroy();
    parede21.destroy();
    parede22.destroy();
    parede23.destroy();
    parede24.destroy();
    parede25.destroy();
    parede26.destroy();
    parede27.destroy();
    parede28.destroy();
    parede29.destroy();
    parede30.destroy();
    pedrinho.destroy();
    jorge.destroy();
    moeda1.destroy();
    moeda2.destroy();
    moeda3.destroy();
  }
  
  if (pontos == 3){
   
    pedrinho.setVelocity(0,0);
    textSize(24);
    text("fim",24,70);
    textSize(24);
    text("agora o pedrinho pode descansar",20,92);
    textSize(18);
    text("sabendo que os malditos cubos amarelos",8,120);
    textSize(24);
    text("não esistem mais",25,150);
   
    parede1.destroy();
    parede2.destroy();
    parede3.destroy();
    parede4.destroy();
    parede5.destroy();
    parede6.destroy();
    parede7.destroy();
    parede8.destroy();
    parede9.destroy();
    parede10.destroy();
    parede11.destroy();
    parede12.destroy();
    parede13.destroy();
    parede14.destroy();
    parede15.destroy();
    parede16.destroy();  
    parede17.destroy();
    parede18.destroy();
    parede19.destroy();
    parede20.destroy();
    parede21.destroy();
    parede22.destroy();
    parede23.destroy();
    parede24.destroy();
    parede25.destroy();
    parede26.destroy();
    parede27.destroy();
    parede28.destroy();
    parede29.destroy();
    parede30.destroy();
    pedrinho.destroy();
    jorge.destroy();
    
  }
  

  
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
